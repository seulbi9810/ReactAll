import React from 'react'

const NotFoundFile = () => {
  return (
    <div>NotFoundFile</div>
  )
}

export default NotFoundFile